<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('benefits', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('user_id');
            $table->unsignedInteger('benefit_type_id');
            $table->boolean('active');
            $table->timestamp('effective_date')->nullable();
            $table->timestamp('enrollment_date')->nullable();
            $table->string('plan');
            $table->string('beneficiary');
            $table->text('notes');
            $table->enum('payment_type', ['na', 'salary', 'shouldered']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('benefits');
    }
};
